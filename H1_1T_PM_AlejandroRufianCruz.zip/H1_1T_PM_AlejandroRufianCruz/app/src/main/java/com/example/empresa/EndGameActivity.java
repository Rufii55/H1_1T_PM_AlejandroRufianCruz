package com.example.empresa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Map;

public class EndGameActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private TextView rankingText;
    private Button restartButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_game);

        prefs = getSharedPreferences("PlayerData", MODE_PRIVATE);
        rankingText = findViewById(R.id.rankingText);
        restartButton = findViewById(R.id.restartButton);

        loadRanking();

        restartButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void loadRanking() {
        StringBuilder ranking = new StringBuilder();
        Map<String, ?> allEntries = prefs.getAll();

        for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
            if (entry.getKey().contains("_score")) {
                String playerName = entry.getKey().split("_")[0];
                int score = (int) entry.getValue();
                String items = prefs.getString(playerName + "_items", "No items");
                ranking.append(playerName).append(": Level ").append(score)
                        .append(", Items: ").append(items).append("\n");
            }
        }

        rankingText.setText(ranking.toString());
    }
}
