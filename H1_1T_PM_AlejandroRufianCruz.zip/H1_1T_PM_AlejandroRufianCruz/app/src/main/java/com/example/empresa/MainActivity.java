package com.example.empresa;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText playerNameInput;
    private Button startGameButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playerNameInput = findViewById(R.id.playerNameInput);
        startGameButton = findViewById(R.id.startGameButton);

        startGameButton.setOnClickListener(view -> {
            String playerName = playerNameInput.getText().toString().trim();
            if (!playerName.isEmpty()) {
                Intent intent = new Intent(MainActivity.this, GameActivity.class);
                intent.putExtra("playerName", playerName);
                startActivity(intent);
                finish();
            } else {
                playerNameInput.setError("Please enter your name");
            }
        });
    }
}
