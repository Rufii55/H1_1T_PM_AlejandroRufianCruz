package com.example.empresa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GameActivity extends AppCompatActivity {

    private int score = 0;
    private int money = 0;
    private int moneyPerClick = 1;
    private int upgradeCost = 100;
    private int[] itemCosts = {1000, 50000, 200000, 500000, 1000000};
    private boolean[] purchasedItems = new boolean[5];
    private SharedPreferences prefs;
    private String playerName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        prefs = getSharedPreferences("PlayerData", MODE_PRIVATE);
        playerName = getIntent().getStringExtra("playerName");

        TextView scoreText = findViewById(R.id.scoreText);
        TextView moneyText = findViewById(R.id.moneyText);
        Button upgradeButton = findViewById(R.id.upgradeButton);
        Button earnMoneyButton = findViewById(R.id.earnMoneyButton);
        Button finishGameButton = findViewById(R.id.finishGameButton);

        Button[] buyItemButtons = new Button[5];
        buyItemButtons[0] = findViewById(R.id.buyItem1);
        buyItemButtons[1] = findViewById(R.id.buyItem2);
        buyItemButtons[2] = findViewById(R.id.buyItem3);
        buyItemButtons[3] = findViewById(R.id.buyItem4);
        buyItemButtons[4] = findViewById(R.id.buyItem5);

        // Mostrar datos iniciales
        scoreText.setText("Level: " + score);
        moneyText.setText("Money: $" + money);

        earnMoneyButton.setOnClickListener(view -> {
            money += moneyPerClick;
            moneyText.setText("Money: $" + money);
        });

        upgradeButton.setText("Upgrade (Cost: $" + upgradeCost + ")");
        upgradeButton.setOnClickListener(view -> {
            if (money >= upgradeCost) {
                money -= upgradeCost;
                moneyPerClick *= 2;
                upgradeCost *= 2;
                moneyText.setText("Money: $" + money);
                upgradeButton.setText("Upgrade (Cost: $" + upgradeCost + ")");
                Toast.makeText(this, "Upgrade successful!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Not enough money!", Toast.LENGTH_SHORT).show();
            }
        });

        for (int i = 0; i < 5; i++) {
            final int itemIndex = i;
            buyItemButtons[i].setText("Buy Item " + (i + 1) + " (Cost: $" + itemCosts[i] + ")");
            buyItemButtons[i].setOnClickListener(view -> {
                if (money >= itemCosts[itemIndex] && !purchasedItems[itemIndex]) {
                    money -= itemCosts[itemIndex];
                    purchasedItems[itemIndex] = true;
                    moneyText.setText("Money: $" + money);
                    buyItemButtons[itemIndex].setEnabled(false);
                    Toast.makeText(this, "Item " + (itemIndex + 1) + " purchased!", Toast.LENGTH_SHORT).show();
                    updatePlayerLevel();
                    scoreText.setText("Level: " + score);
                } else if (purchasedItems[itemIndex]) {
                    Toast.makeText(this, "You already own this item!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Not enough money!", Toast.LENGTH_SHORT).show();
                }
            });
        }

        finishGameButton.setOnClickListener(view -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt(playerName + "_score", score);
            editor.putInt(playerName + "_money", money);
            editor.putString(playerName + "_items", getPurchasedItems());
            editor.apply();

            Intent intent = new Intent(this, EndGameActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void updatePlayerLevel() {
        score = 0;
        for (boolean item : purchasedItems) {
            if (item) score++;
        }
    }

    private String getPurchasedItems() {
        StringBuilder items = new StringBuilder();
        for (int i = 0; i < purchasedItems.length; i++) {
            if (purchasedItems[i]) {
                items.append("Item ").append(i + 1).append(" ");
            }
        }
        return items.toString().trim();
    }
}
